# Event Collector Service

Spring Boot microservice that implements the Transactional Outbox pattern for processing IoT device events.

## Overview

The Event Collector Service:
- Consumes Avro-encoded events from Kafka topic `events` (one-by-one processing)
- Saves events to ClickHouse `device_events` table
- Creates outbox records in ClickHouse `device_outbox` for all devices (status=PENDING)
- CRON job processes outbox with Redis row-level locking for horizontal scaling
- Deduplicates device IDs using Redis Set (`devices:published`) during outbox processing
- Publishes device IDs to Kafka topic `devices`
- Retry mechanism with max 5 attempts, marks failed records as FAILED

## Architecture

### Key Components

- [DeviceEventListener](src/main/java/com/nashcode/event_collector/kafka/consumer/DeviceEventListener.java) - Kafka consumer for `events` topic
- [EventProcessorService](src/main/java/com/nashcode/event_collector/service/EventProcessorService.java) - Processes events and creates outbox records
- [OutboxScheduler](src/main/java/com/nashcode/event_collector/scheduler/OutboxScheduler.java) - CRON scheduler for outbox processing
- [OutboxProcessorService](src/main/java/com/nashcode/event_collector/service/OutboxProcessorService.java) - Processes outbox records with retry logic
- [DevicePublisher](src/main/java/com/nashcode/event_collector/kafka/producer/DevicePublisher.java) - Kafka producer for `devices` topic
- [DistributedLockService](src/main/java/com/nashcode/event_collector/service/DistributedLockService.java) - Redis-based row-level locking
- [RedisDeduplicationRepository](src/main/java/com/nashcode/event_collector/repository/RedisDeduplicationRepository.java) - Device deduplication using Redis Set

### Event Processing Flow

1. **Kafka Consumer** receives Avro event from `events` topic (max.poll.records=1)
2. **Save Event**: Insert into ClickHouse `device_events` table
3. **Outbox Record**: Create record in ClickHouse `device_outbox` (status=PENDING)
4. **Manual Acknowledgment**: Only commit Kafka offset after both operations succeed

### Outbox Processing Flow (CRON Job)

1. **Find Oldest Pending**: SELECT WHERE status IN (PENDING, RETRY) ORDER BY created_at ASC LIMIT 100
2. **For Each Record**:
   - Check if attempts >= max-attempts (5) → mark as FAILED
   - **Acquire Lock**: Redis SETNX `outbox:lock:{device_id}` with 30-second TTL
   - If lock not acquired → skip record (another instance processing)
   - **Double-Check**: Use Redis `devices:published` SADD to check if already published
   - If already published → mark outbox as SENT (deduplication)
   - **Publish to Kafka**: Send device_id to `devices` topic
   - **Update Status**: Mark outbox record as SENT
   - **Error Handling**: On failure, update to RETRY with attempts++ and error message
   - **Release Lock**: Explicitly release lock in finally block (or TTL expires)

### Horizontal Scaling Strategy

- Multiple service instances share Kafka consumer group (Kafka distributes partitions)
- Redis row-level locking (`outbox:lock:{device_id}`) prevents duplicate outbox processing
- Double-check pattern with `devices:published` Redis Set (SADD atomic operation) prevents duplicate publishes
- Lock TTL (30 seconds) ensures locks don't block forever if instance crashes
- Batch processing (LIMIT 100) allows multiple instances to process different records simultaneously

## Configuration

- **Profiles**: `local` (localhost) and `docker` (Docker Compose network)
- **Key settings**: CRON every 5s, lock TTL 30s, max 5 retry attempts
- See full configuration: [application.yaml](src/main/resources/application.yaml)

## Data Storage

**ClickHouse Tables:**
- `device_events` - Event storage (partitioned by date)
- `device_outbox` - Outbox pattern table (status: PENDING/RETRY/SENT/FAILED)

**Redis Keys:**
- `devices:published` - Device deduplication set
- `outbox:lock:{device_id}` - Row-level locks (30s TTL)

See: [Flyway Migrations](src/main/resources/db/migration/), [OutboxStatus enum](src/main/java/com/nashcode/event_collector/domain/model/OutboxStatus.java)

## Quick Start

```bash
# From project root
make up                           # Start infrastructure
make health                       # Verify all services running
cd event-collector
./gradlew bootRun                # Run with 'local' profile (default)
make produce-test-event          # Send test event (from project root)
```

See project root [Makefile](../Makefile) for all available commands.

## Verification

```bash
make logs-service SERVICE=event-collector                    # View logs
docker exec -it clickhouse clickhouse-client -q "SELECT * FROM telemetry.device_events"    # Check events
docker exec -it clickhouse clickhouse-client -q "SELECT * FROM telemetry.device_outbox"    # Check outbox
docker exec -it redis redis-cli -a redis_password SMEMBERS devices:published              # Check deduplication
```

Health check: `curl http://localhost:8087/actuator/health`

## Testing

**Deduplication:**
```bash
# Send multiple events for same device
./scripts/produce-test-event.sh evt-{001..003} dev-456
# Verify: All events saved, but only one publish to 'devices' topic
```

**Horizontal Scaling:**
```bash
# Terminal 1: SERVER_PORT=8087 ./gradlew bootRun
# Terminal 2: SERVER_PORT=8088 ./gradlew bootRun
# Send events → both instances process, Redis locks prevent duplicates
```

**Integration Tests:**
```bash
./gradlew test  # Testcontainers-based integration tests
```

## Monitoring

- Health: `http://localhost:8087/actuator/health`
- Metrics: `http://localhost:8087/actuator/prometheus`
- Grafana: `http://localhost:3009` (admin/admin)

## Error Handling

**Event Processing:** Manual Kafka acknowledgment ensures at-least-once delivery. See [DeviceEventListener](src/main/java/com/nashcode/event_collector/kafka/consumer/DeviceEventListener.java).

**Outbox Processing:** Retry up to 5 times with exponential backoff, then mark FAILED. Redis locks prevent concurrent processing. See [OutboxProcessorService](src/main/java/com/nashcode/event_collector/service/OutboxProcessorService.java).

## Key Design Decisions

1. **Transactional Outbox Pattern**: Events and outbox records created together, published asynchronously (see [EventProcessorService](src/main/java/com/nashcode/event_collector/service/EventProcessorService.java))
2. **One-by-one Processing**: `max.poll.records=1` ensures each event is fully processed before consuming the next
3. **Manual Acknowledgment**: Only commit Kafka offset after both ClickHouse writes succeed
4. **Row-level Locking**: Redis `SETNX outbox:lock:{device_id}` with TTL enables horizontal scaling (see [DistributedLockService](src/main/java/com/nashcode/event_collector/service/DistributedLockService.java))
5. **Double-check Pattern**: Redis `devices:published` SADD (atomic) prevents duplicate publishes (see [RedisDeduplicationRepository](src/main/java/com/nashcode/event_collector/repository/RedisDeduplicationRepository.java))
6. **Retry with Backoff**: Failed outbox records retry up to 5 times, then marked FAILED (see [OutboxProcessorService](src/main/java/com/nashcode/event_collector/service/OutboxProcessorService.java))
7. **Lock TTL**: 30-second TTL ensures locks don't block forever if instance crashes

## Troubleshooting

- **Won't start**: Run `make health` to verify infrastructure
- **No events consumed**: Check Kafka topics and consumer group status
- **Outbox not processing**: Verify CRON schedule, Redis locks, and pending records
- **Duplicate publishes**: Check `devices:published` Redis set and lock acquisition logs

See detailed troubleshooting: [TROUBLESHOOTING.md](TROUBLESHOOTING.md)

## License

Educational project for demonstrating microservices patterns.
