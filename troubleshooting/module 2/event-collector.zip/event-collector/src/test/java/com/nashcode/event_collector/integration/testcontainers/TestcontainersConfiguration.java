package com.nashcode.event_collector.integration.testcontainers;

import org.testcontainers.containers.ClickHouseContainer;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.Network;
import org.testcontainers.kafka.KafkaContainer;
import org.testcontainers.utility.DockerImageName;

/**
 * Centralized Testcontainers configuration for all integration tests.
 * Usage: Tests should extend this class or reference these static containers.
 */
public abstract class TestcontainersConfiguration {

	protected static final Network network = Network.newNetwork();

	protected static final KafkaContainer kafka = new KafkaContainer(DockerImageName.parse("apache/kafka:3.8.1"))
			.withNetwork(network)
			.withNetworkAliases("broker");

	protected static final GenericContainer<?> schemaRegistry = new GenericContainer<>(DockerImageName.parse("confluentinc/cp-schema-registry:8.0.3"))
			.withNetwork(network)
			.withNetworkAliases("schema-registry")
			.withExposedPorts(8081)
			.withEnv("SCHEMA_REGISTRY_HOST_NAME", "schema-registry")
			.withEnv("SCHEMA_REGISTRY_LISTENERS", "http://0.0.0.0:8081")
			.withEnv("SCHEMA_REGISTRY_KAFKASTORE_BOOTSTRAP_SERVERS", "PLAINTEXT://broker:9093")
			.withEnv("SCHEMA_REGISTRY_KAFKASTORE_TIMEOUT_MS", "30000")
			.dependsOn(kafka);

	protected static final ClickHouseContainer clickHouse = new ClickHouseContainer(DockerImageName.parse("clickhouse/clickhouse-server:24.3.1"))
			.withInitScript("clickhouse-init.sql");

	protected static final GenericContainer<?> redis = new GenericContainer<>(DockerImageName.parse("redis:8-alpine"))
			.withExposedPorts(6379);
}
