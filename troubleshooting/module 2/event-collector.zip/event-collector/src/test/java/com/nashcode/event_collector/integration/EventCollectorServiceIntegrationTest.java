package com.nashcode.event_collector.integration;

import com.nashcode.event_collector.integration.testcontainers.TestcontainersConfiguration;
import com.nashcode.avro.DeviceEvent;
import com.nashcode.event_collector.domain.model.OutboxStatus;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.ClickHouseContainer;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.kafka.KafkaContainer;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

/**
 * Full end-to-end integration test with Kafka, Schema Registry, ClickHouse, and Redis.
 *
 * Flow:
 * 1. Start all containers (Kafka, Schema Registry, ClickHouse, Redis)
 * 2. Send DeviceEvent to Kafka 'events' topic using Avro serialization
 * 3. Kafka listener consumes the event
 * 4. EventProcessorService saves to device_events and creates device_outbox record
 * 5. Verify data in ClickHouse
 */
@SpringBootTest
@Testcontainers
@org.springframework.test.context.ActiveProfiles("test")
class EventCollectorServiceIntegrationTest extends TestcontainersConfiguration {

    @Container
    static KafkaContainer kafkaContainer = kafka;

    @Container
    static GenericContainer<?> schemaRegistryContainer = schemaRegistry;

    @Container
    static ClickHouseContainer clickHouseContainer = clickHouse;

    @Container
    static GenericContainer<?> redisContainer = redis;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private KafkaProducer<String, DeviceEvent> avroProducer;

    private static final String EVENTS_TOPIC = "events";

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        // Kafka configuration
        registry.add("spring.kafka.bootstrap-servers", kafkaContainer::getBootstrapServers);

        // Schema Registry configuration
        String schemaRegistryUrl = "http://" + schemaRegistryContainer.getHost() + ":" + schemaRegistryContainer.getMappedPort(8081);
        registry.add("spring.kafka.consumer.properties.schema.registry.url", () -> schemaRegistryUrl);
        registry.add("spring.kafka.producer.properties.schema.registry.url", () -> schemaRegistryUrl);

        // ClickHouse configuration
        registry.add("spring.datasource.url", () -> clickHouseContainer.getJdbcUrl());
        registry.add("spring.datasource.username", clickHouseContainer::getUsername);
        registry.add("spring.datasource.password", clickHouseContainer::getPassword);

        // Redis configuration
        registry.add("spring.data.redis.host", redisContainer::getHost);
        registry.add("spring.data.redis.port", () -> redisContainer.getMappedPort(6379));
        registry.add("spring.data.redis.password", () -> "");

        // Topics
        registry.add("kafka.topics.events", () -> EVENTS_TOPIC);
        registry.add("kafka.topics.devices", () -> "devices");
    }

    @BeforeEach
    void setUp() {
        // Clean up ClickHouse tables
        jdbcTemplate.execute("TRUNCATE TABLE telemetry.device_events");
        jdbcTemplate.execute("TRUNCATE TABLE telemetry.device_outbox");

        // Wait for Schema Registry to be ready
        waitForSchemaRegistry();

        // Initialize Avro producer
        Map<String, Object> producerProps = new HashMap<>();
        producerProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaContainer.getBootstrapServers());
        producerProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);
        producerProps.put("schema.registry.url", "http://" + schemaRegistryContainer.getHost() + ":" + schemaRegistryContainer.getMappedPort(8081));

        avroProducer = new KafkaProducer<>(producerProps);
    }

    private void waitForSchemaRegistry() {
        String schemaRegistryUrl = "http://" + schemaRegistryContainer.getHost() + ":" + schemaRegistryContainer.getMappedPort(8081);
        await().atMost(Duration.ofSeconds(60))
                .pollInterval(Duration.ofSeconds(2))
                .ignoreExceptions()
                .untilAsserted(() -> {
                    try {
                        java.net.HttpURLConnection connection = (java.net.HttpURLConnection)
                                new java.net.URL(schemaRegistryUrl + "/subjects").openConnection();
                        connection.setRequestMethod("GET");
                        connection.setConnectTimeout(5000);
                        connection.setReadTimeout(5000);
                        int responseCode = connection.getResponseCode();
                        connection.disconnect();
                        assertThat(responseCode).isEqualTo(200);
                    } catch (Exception e) {
                        throw new RuntimeException("Schema Registry not ready", e);
                    }
                });
        System.out.println("✓ Schema Registry is ready");
    }

    @Test
    void shouldVerifyAllContainersAreRunning() {
        assertThat(kafkaContainer.isRunning()).as("Kafka should be running").isTrue();
        assertThat(schemaRegistryContainer.isRunning()).as("Schema Registry should be running").isTrue();
        assertThat(clickHouseContainer.isRunning()).as("ClickHouse should be running").isTrue();
        assertThat(redisContainer.isRunning()).as("Redis should be running").isTrue();

        // Verify ClickHouse schema
        Long deviceEventsCount = jdbcTemplate.queryForObject(
                "SELECT count() FROM system.tables WHERE database = 'telemetry' AND name = 'device_events'",
                Long.class
        );
        assertThat(deviceEventsCount).isEqualTo(1L);

        Long deviceOutboxCount = jdbcTemplate.queryForObject(
                "SELECT count() FROM system.tables WHERE database = 'telemetry' AND name = 'device_outbox'",
                Long.class
        );
        assertThat(deviceOutboxCount).isEqualTo(1L);
    }

    @Test
    void shouldConsumeAvroEventAndSaveToClickHouse_newDevice() throws Exception {
        // Given - Create a new device event
        String deviceId = "device-avro-" + UUID.randomUUID();
        String eventId = "event-avro-" + UUID.randomUUID();
        long timestamp = System.currentTimeMillis();

        DeviceEvent event = DeviceEvent.newBuilder()
                .setEventId(eventId)
                .setDeviceId(deviceId)
                .setTimestamp(timestamp)
                .setType("TEMPERATURE")
                .setPayload("{\"temperature\": 25.5, \"unit\": \"C\"}")
                .build();

        // When - Send Avro event to Kafka events topic
        ProducerRecord<String, DeviceEvent> record = new ProducerRecord<>(EVENTS_TOPIC, deviceId, event);
        avroProducer.send(record).get();
        avroProducer.flush();

        System.out.println("Sent Avro event: deviceId=" + deviceId + ", eventId=" + eventId);

        // Then - Wait for event to be consumed and saved to device_events
        await().atMost(Duration.ofSeconds(15))
                .pollInterval(Duration.ofMillis(500))
                .untilAsserted(() -> {
                    Long eventCount = jdbcTemplate.queryForObject(
                            "SELECT count() FROM telemetry.device_events WHERE event_id = ?",
                            Long.class,
                            eventId
                    );
                    assertThat(eventCount)
                            .as("Event should be saved in device_events table")
                            .isEqualTo(1L);
                });

        // Verify event details
        Map<String, Object> savedEvent = jdbcTemplate.queryForMap(
                "SELECT * FROM telemetry.device_events WHERE event_id = ?",
                eventId
        );
        assertThat(savedEvent.get("device_id")).isEqualTo(deviceId);
        assertThat(savedEvent.get("event_id")).isEqualTo(eventId);
        assertThat(savedEvent.get("type")).isEqualTo("TEMPERATURE");
        assertThat(savedEvent.get("payload")).isEqualTo("{\"temperature\": 25.5, \"unit\": \"C\"}");

        System.out.println("✓ Event saved to device_events: " + savedEvent);

        // And - Verify outbox record is created for new device
        await().atMost(Duration.ofSeconds(5))
                .untilAsserted(() -> {
                    Long outboxCount = jdbcTemplate.queryForObject(
                            "SELECT count() FROM telemetry.device_outbox WHERE device_id = ?",
                            Long.class,
                            deviceId
                    );
                    assertThat(outboxCount)
                            .as("Outbox record should be created for new device")
                            .isEqualTo(1L);
                });

        // Verify outbox details
        Map<String, Object> outboxRecord = jdbcTemplate.queryForMap(
                "SELECT * FROM telemetry.device_outbox WHERE device_id = ?",
                deviceId
        );
        assertThat(outboxRecord.get("device_id")).isEqualTo(deviceId);
        assertThat(((Number) outboxRecord.get("status")).intValue()).isEqualTo(OutboxStatus.PENDING.getValue());
        assertThat(((Number) outboxRecord.get("attempts")).longValue()).isEqualTo(0L);

        System.out.println("✓ Outbox record created: " + outboxRecord);
    }

    @Test
    void shouldConsumeMultipleAvroEvents() throws Exception {
        // Given - Create 3 different devices with events
        String[] deviceIds = new String[3];
        String[] eventIds = new String[3];

        for (int i = 0; i < 3; i++) {
            deviceIds[i] = "device-multi-" + i + "-" + UUID.randomUUID();
            eventIds[i] = "event-multi-" + i + "-" + UUID.randomUUID();

            DeviceEvent event = DeviceEvent.newBuilder()
                    .setEventId(eventIds[i])
                    .setDeviceId(deviceIds[i])
                    .setTimestamp(System.currentTimeMillis())
                    .setType("HUMIDITY")
                    .setPayload("{\"humidity\": " + (50 + i * 10) + "}")
                    .build();

            // When - Send events to Kafka
            avroProducer.send(new ProducerRecord<>(EVENTS_TOPIC, deviceIds[i], event)).get();
        }
        avroProducer.flush();

        System.out.println("Sent 3 Avro events");

        // Then - Wait for all events to be consumed and saved
        await().atMost(Duration.ofSeconds(20))
                .pollInterval(Duration.ofMillis(500))
                .untilAsserted(() -> {
                    Long eventCount = jdbcTemplate.queryForObject(
                            "SELECT count() FROM telemetry.device_events WHERE device_id LIKE 'device-multi-%'",
                            Long.class
                    );
                    assertThat(eventCount).isEqualTo(3L);
                });

        // Verify all 3 outbox records are created
        await().atMost(Duration.ofSeconds(5))
                .untilAsserted(() -> {
                    Long outboxCount = jdbcTemplate.queryForObject(
                            "SELECT count() FROM telemetry.device_outbox WHERE device_id LIKE 'device-multi-%'",
                            Long.class
                    );
                    assertThat(outboxCount).isEqualTo(3L);
                });

        // Verify each event is saved correctly
        for (int i = 0; i < 3; i++) {
            Map<String, Object> savedEvent = jdbcTemplate.queryForMap(
                    "SELECT * FROM telemetry.device_events WHERE event_id = ?",
                    eventIds[i]
            );
            assertThat(savedEvent.get("device_id")).isEqualTo(deviceIds[i]);
            assertThat(savedEvent.get("type")).isEqualTo("HUMIDITY");
            assertThat((String) savedEvent.get("payload")).contains("humidity");
        }

        System.out.println("✓ All 3 events and outbox records saved successfully");
    }

    @Test
    void shouldHandleSameDeviceMultipleEvents() throws Exception {
        // Given - Same device sends 2 events
        String deviceId = "device-same-" + UUID.randomUUID();
        String eventId1 = "event-1-" + UUID.randomUUID();
        String eventId2 = "event-2-" + UUID.randomUUID();

        DeviceEvent event1 = DeviceEvent.newBuilder()
                .setEventId(eventId1)
                .setDeviceId(deviceId)
                .setTimestamp(System.currentTimeMillis())
                .setType("TEMPERATURE")
                .setPayload("{\"temperature\": 20.0}")
                .build();

        DeviceEvent event2 = DeviceEvent.newBuilder()
                .setEventId(eventId2)
                .setDeviceId(deviceId)
                .setTimestamp(System.currentTimeMillis() + 1000)
                .setType("HUMIDITY")
                .setPayload("{\"humidity\": 65.0}")
                .build();

        // When - Send both events
        avroProducer.send(new ProducerRecord<>(EVENTS_TOPIC, deviceId, event1)).get();
        avroProducer.send(new ProducerRecord<>(EVENTS_TOPIC, deviceId, event2)).get();
        avroProducer.flush();

        System.out.println("Sent 2 events from same device: " + deviceId);

        // Then - Both events should be saved
        await().atMost(Duration.ofSeconds(20))
                .pollInterval(Duration.ofMillis(500))
                .untilAsserted(() -> {
                    Long eventCount = jdbcTemplate.queryForObject(
                            "SELECT count() FROM telemetry.device_events WHERE device_id = ?",
                            Long.class,
                            deviceId
                    );
                    assertThat(eventCount).isEqualTo(2L);
                });

        // Verify both events are in device_events
        Map<String, Object> savedEvent1 = jdbcTemplate.queryForMap(
                "SELECT * FROM telemetry.device_events WHERE event_id = ?",
                eventId1
        );
        assertThat(savedEvent1.get("type")).isEqualTo("TEMPERATURE");

        Map<String, Object> savedEvent2 = jdbcTemplate.queryForMap(
                "SELECT * FROM telemetry.device_events WHERE event_id = ?",
                eventId2
        );
        assertThat(savedEvent2.get("type")).isEqualTo("HUMIDITY");

        // And - At least one outbox record should be created
        // (implementation may create one per event or deduplicate)
        await().atMost(Duration.ofSeconds(5))
                .untilAsserted(() -> {
                    Long outboxCount = jdbcTemplate.queryForObject(
                            "SELECT count() FROM telemetry.device_outbox WHERE device_id = ?",
                            Long.class,
                            deviceId
                    );
                    assertThat(outboxCount).isGreaterThanOrEqualTo(1L);
                });

        System.out.println("✓ Both events saved, outbox records created");
    }
}
