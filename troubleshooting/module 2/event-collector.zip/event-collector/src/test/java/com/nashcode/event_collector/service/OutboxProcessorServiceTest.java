package com.nashcode.event_collector.service;

import com.nashcode.event_collector.domain.entity.DeviceOutboxEntity;
import com.nashcode.event_collector.domain.exception.OutboxProcessingException;
import com.nashcode.event_collector.domain.model.OutboxStatus;
import com.nashcode.event_collector.kafka.producer.DevicePublisher;
import com.nashcode.event_collector.repository.DeviceOutboxRepository;
import com.nashcode.event_collector.repository.RedisDeduplicationRepository;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanBuilder;
import io.opentelemetry.api.trace.Tracer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
class OutboxProcessorServiceTest {

    @Mock
    private DeviceOutboxRepository outboxRepository;

    @Mock
    private DistributedLockService lockService;

    @Mock
    private DevicePublisher devicePublisher;

    @Mock
    private RedisDeduplicationRepository deduplicationRepository;

    @Mock
    private MetricsService metricsService;

    @Mock
    private Tracer tracer;

    @Mock
    private SpanBuilder spanBuilder;

    @Mock
    private Span span;

    private OutboxProcessorService outboxProcessorService;

    private static final int MAX_ATTEMPTS = 5;

    @BeforeEach
    void setUp() {
        lenient().when(tracer.spanBuilder(anyString())).thenReturn(spanBuilder);
        lenient().when(spanBuilder.setParent(any())).thenReturn(spanBuilder);
        lenient().when(spanBuilder.setSpanKind(any())).thenReturn(spanBuilder);
        lenient().when(spanBuilder.setAttribute(anyString(), anyString())).thenReturn(spanBuilder);
        lenient().when(spanBuilder.setAttribute(anyString(), anyBoolean())).thenReturn(spanBuilder);
        lenient().when(spanBuilder.startSpan()).thenReturn(span);
        lenient().when(span.makeCurrent()).thenReturn(() -> {});

        outboxProcessorService = new OutboxProcessorService(
                outboxRepository,
                lockService,
                devicePublisher,
                deduplicationRepository,
                metricsService,
                tracer,
                MAX_ATTEMPTS
        );
    }

    @Test
    void processOutboxRecords_shouldDoNothing_whenNoRecordsFound() {
        // Given
        when(outboxRepository.findOldestDevicesToProcess()).thenReturn(Collections.emptyList());

        // When
        outboxProcessorService.processOutboxRecords();

        // Then
        verify(outboxRepository).findOldestDevicesToProcess();
        verifyNoInteractions(lockService, devicePublisher, deduplicationRepository, metricsService);
    }

    @Test
    void processOutboxRecords_shouldMarkAsFailed_whenMaxAttemptsExceeded() {
        // Given
        DeviceOutboxEntity outboxRecord = createOutboxRecord("device-123", MAX_ATTEMPTS, OutboxStatus.RETRY);
        when(outboxRepository.findOldestDevicesToProcess()).thenReturn(List.of(outboxRecord));

        // When
        outboxProcessorService.processOutboxRecords();

        // Then
        verify(outboxRepository).updateToFailed("device-123", "Exceeded max attempts: " + MAX_ATTEMPTS);
        verifyNoInteractions(lockService, devicePublisher, deduplicationRepository);
        verify(metricsService, never()).incrementOutboxPublishSuccess();
        verify(metricsService, never()).incrementOutboxPublishFail();
    }

    @Test
    void processOutboxRecords_shouldSkipRecord_whenLockNotAcquired() {
        // Given
        DeviceOutboxEntity outboxRecord = createOutboxRecord("device-123", 0, OutboxStatus.PENDING);
        when(outboxRepository.findOldestDevicesToProcess()).thenReturn(List.of(outboxRecord));
        when(lockService.acquireLock("outbox:lock:device-123")).thenReturn(false);

        // When
        outboxProcessorService.processOutboxRecords();

        // Then
        verify(lockService).acquireLock("outbox:lock:device-123");
        verifyNoInteractions(devicePublisher, deduplicationRepository);
        verify(lockService, never()).releaseLock(anyString());
        verify(metricsService, never()).incrementOutboxPublishSuccess();
    }

    @Test
    void processOutboxRecords_shouldPublishDevice_whenNewDevice() {
        // Given
        DeviceOutboxEntity outboxRecord = createOutboxRecord("device-123", 0, OutboxStatus.PENDING);
        when(outboxRepository.findOldestDevicesToProcess()).thenReturn(List.of(outboxRecord));
        when(lockService.acquireLock("outbox:lock:device-123")).thenReturn(true);
        when(deduplicationRepository.addToPublishedIfNew("device-123")).thenReturn(true);
        doNothing().when(devicePublisher).publishDevice("device-123");

        // When
        outboxProcessorService.processOutboxRecords();

        // Then
        verify(lockService).acquireLock("outbox:lock:device-123");
        verify(deduplicationRepository).addToPublishedIfNew("device-123");
        verify(devicePublisher).publishDevice("device-123");
        verify(outboxRepository).updateToSent("device-123");
        verify(lockService).releaseLock("outbox:lock:device-123");
        verify(metricsService).incrementOutboxPublishSuccess();
        verify(metricsService, never()).incrementOutboxPublishFail();
    }

    @Test
    void processOutboxRecords_shouldSkipPublishing_whenDeviceAlreadyPublished() {
        // Given
        DeviceOutboxEntity outboxRecord = createOutboxRecord("device-123", 0, OutboxStatus.PENDING);
        when(outboxRepository.findOldestDevicesToProcess()).thenReturn(List.of(outboxRecord));
        when(lockService.acquireLock("outbox:lock:device-123")).thenReturn(true);
        when(deduplicationRepository.addToPublishedIfNew("device-123")).thenReturn(false);

        // When
        outboxProcessorService.processOutboxRecords();

        // Then
        verify(lockService).acquireLock("outbox:lock:device-123");
        verify(deduplicationRepository).addToPublishedIfNew("device-123");
        verify(devicePublisher, never()).publishDevice(anyString());
        verify(outboxRepository).updateToSent("device-123");
        verify(lockService).releaseLock("outbox:lock:device-123");
        verify(metricsService).incrementOutboxPublishSuccess();
        verify(metricsService, never()).incrementOutboxPublishFail();
    }

    @Test
    void processOutboxRecords_shouldUpdateToRetry_whenPublishFails() {
        // Given
        DeviceOutboxEntity outboxRecord = createOutboxRecord("device-123", 0, OutboxStatus.PENDING);
        when(outboxRepository.findOldestDevicesToProcess()).thenReturn(List.of(outboxRecord));
        when(lockService.acquireLock("outbox:lock:device-123")).thenReturn(true);
        when(deduplicationRepository.addToPublishedIfNew("device-123")).thenReturn(true);
        doThrow(new RuntimeException("Kafka error")).when(devicePublisher).publishDevice("device-123");

        // When & Then
        assertThatThrownBy(() -> outboxProcessorService.processOutboxRecords())
                .isInstanceOf(OutboxProcessingException.class)
                .hasMessageContaining("Failed to process outboxRecords for device: device-123")
                .hasCauseInstanceOf(RuntimeException.class);

        verify(devicePublisher).publishDevice("device-123");
        verify(outboxRepository).updateToRetry("device-123", "Kafka error");
        verify(outboxRepository, never()).updateToSent(anyString());
        verify(lockService).releaseLock("outbox:lock:device-123");
        verify(metricsService).incrementOutboxPublishFail();
        verify(metricsService, never()).incrementOutboxPublishSuccess();
    }

    @Test
    void processOutboxRecords_shouldReleaseLock_whenExceptionOccurs() {
        // Given
        DeviceOutboxEntity outboxRecord = createOutboxRecord("device-123", 0, OutboxStatus.PENDING);
        when(outboxRepository.findOldestDevicesToProcess()).thenReturn(List.of(outboxRecord));
        when(lockService.acquireLock("outbox:lock:device-123")).thenReturn(true);
        when(deduplicationRepository.addToPublishedIfNew("device-123")).thenReturn(true);
        doThrow(new RuntimeException("Unexpected error")).when(devicePublisher).publishDevice("device-123");

        // When & Then
        assertThatThrownBy(() -> outboxProcessorService.processOutboxRecords())
                .isInstanceOf(OutboxProcessingException.class);

        // Then - verify lock is released even on exception (finally block)
        verify(lockService).releaseLock("outbox:lock:device-123");
    }

    @Test
    void processOutboxRecords_shouldProcessMultipleRecords() {
        // Given
        DeviceOutboxEntity record1 = createOutboxRecord("device-1", 0, OutboxStatus.PENDING);
        DeviceOutboxEntity record2 = createOutboxRecord("device-2", 0, OutboxStatus.PENDING);
        when(outboxRepository.findOldestDevicesToProcess()).thenReturn(List.of(record1, record2));
        when(lockService.acquireLock(anyString())).thenReturn(true);
        when(deduplicationRepository.addToPublishedIfNew(anyString())).thenReturn(true);

        // When
        outboxProcessorService.processOutboxRecords();

        // Then
        verify(devicePublisher).publishDevice("device-1");
        verify(devicePublisher).publishDevice("device-2");
        verify(outboxRepository).updateToSent("device-1");
        verify(outboxRepository).updateToSent("device-2");
        verify(lockService).releaseLock("outbox:lock:device-1");
        verify(lockService).releaseLock("outbox:lock:device-2");
        verify(metricsService, times(2)).incrementOutboxPublishSuccess();
    }

    @Test
    void processOutboxRecords_shouldContinueProcessing_whenOneRecordFails() {
        // Given
        DeviceOutboxEntity record1 = createOutboxRecord("device-1", 0, OutboxStatus.PENDING);
        DeviceOutboxEntity record2 = createOutboxRecord("device-2", 0, OutboxStatus.PENDING);
        when(outboxRepository.findOldestDevicesToProcess()).thenReturn(List.of(record1, record2));
        when(lockService.acquireLock(anyString())).thenReturn(true);
        when(deduplicationRepository.addToPublishedIfNew(anyString())).thenReturn(true);

        // First device fails
        doThrow(new RuntimeException("Kafka error")).when(devicePublisher).publishDevice("device-1");

        // When & Then - first record throws exception
        assertThatThrownBy(() -> outboxProcessorService.processOutboxRecords())
                .isInstanceOf(OutboxProcessingException.class)
                .hasMessageContaining("device-1");

        // Then - verify first record was attempted and failed
        verify(outboxRepository).updateToRetry("device-1", "Kafka error");
        verify(lockService).releaseLock("outbox:lock:device-1");
        verify(metricsService).incrementOutboxPublishFail();

        // Second record is not processed due to exception thrown by first
        verify(devicePublisher, never()).publishDevice("device-2");
    }

    @Test
    void processOutboxRecords_shouldHandleMixedScenarios() {
        // Given - 3 records: max attempts, lock failed, successful
        DeviceOutboxEntity maxAttemptsRecord = createOutboxRecord("device-max", MAX_ATTEMPTS, OutboxStatus.RETRY);
        DeviceOutboxEntity lockFailedRecord = createOutboxRecord("device-locked", 1, OutboxStatus.PENDING);
        DeviceOutboxEntity successRecord = createOutboxRecord("device-success", 0, OutboxStatus.PENDING);

        when(outboxRepository.findOldestDevicesToProcess())
                .thenReturn(List.of(maxAttemptsRecord, lockFailedRecord, successRecord));
        when(lockService.acquireLock("outbox:lock:device-locked")).thenReturn(false);
        when(lockService.acquireLock("outbox:lock:device-success")).thenReturn(true);
        when(deduplicationRepository.addToPublishedIfNew("device-success")).thenReturn(true);

        // When
        outboxProcessorService.processOutboxRecords();

        // Then
        verify(outboxRepository).updateToFailed("device-max", "Exceeded max attempts: " + MAX_ATTEMPTS);
        verify(devicePublisher, never()).publishDevice("device-locked");
        verify(devicePublisher).publishDevice("device-success");
        verify(outboxRepository).updateToSent("device-success");
        verify(metricsService).incrementOutboxPublishSuccess();
    }

    @Test
    void processOutboxRecords_shouldNotReleaseLock_whenLockNotAcquired() {
        // Given
        DeviceOutboxEntity outboxRecord = createOutboxRecord("device-123", 0, OutboxStatus.PENDING);
        when(outboxRepository.findOldestDevicesToProcess()).thenReturn(List.of(outboxRecord));
        when(lockService.acquireLock("outbox:lock:device-123")).thenReturn(false);

        // When
        outboxProcessorService.processOutboxRecords();

        // Then - lock should not be released if it was never acquired
        verify(lockService).acquireLock("outbox:lock:device-123");
        verify(lockService, never()).releaseLock(anyString());
    }

    private DeviceOutboxEntity createOutboxRecord(String deviceId, int attempts, OutboxStatus status) {
        DeviceOutboxEntity entity = new DeviceOutboxEntity();
        entity.setDeviceId(deviceId);
        entity.setCreatedAt(LocalDateTime.now());
        entity.setStatus(status);
        entity.setAttempts(attempts);
        entity.setTraceparent("00-0af7651916cd43dd8448eb211c80319c-b7ad6b7169203331-01");
        return entity;
    }
}
