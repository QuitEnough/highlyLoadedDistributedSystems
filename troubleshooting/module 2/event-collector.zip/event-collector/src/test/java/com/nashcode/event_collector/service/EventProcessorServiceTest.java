package com.nashcode.event_collector.service;

import com.nashcode.avro.DeviceEvent;
import com.nashcode.event_collector.domain.entity.DeviceEventEntity;
import com.nashcode.event_collector.domain.exception.EventProcessingException;
import com.nashcode.event_collector.repository.DeviceEventRepository;
import com.nashcode.event_collector.repository.DeviceOutboxRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EventProcessorServiceTest {

    @Mock
    private DeviceEventRepository eventRepository;

    @Mock
    private DeviceOutboxRepository outboxRepository;

    @Mock
    private MetricsService metricsService;

    @InjectMocks
    private EventProcessorService eventProcessorService;

    private DeviceEvent testEvent;

    @BeforeEach
    void setUp() {
        testEvent = DeviceEvent.newBuilder()
                .setEventId("event-123")
                .setDeviceId("device-456")
                .setTimestamp(System.currentTimeMillis())
                .setType("TEMPERATURE")
                .setPayload("{\"temperature\": 25.5}")
                .build();
    }

    @Test
    void processEvent_shouldSaveEventAndCreateOutboxRecord() {
        // When
        eventProcessorService.processEvent(testEvent);

        // Then
        ArgumentCaptor<DeviceEventEntity> entityCaptor = ArgumentCaptor.forClass(DeviceEventEntity.class);
        verify(eventRepository).save(entityCaptor.capture());

        DeviceEventEntity savedEntity = entityCaptor.getValue();
        assertThat(savedEntity.getEventId()).isEqualTo("event-123");
        assertThat(savedEntity.getDeviceId()).isEqualTo("device-456");
        assertThat(savedEntity.getType()).isEqualTo("TEMPERATURE");
        assertThat(savedEntity.getPayload()).isEqualTo("{\"temperature\": 25.5}");

        verify(outboxRepository).createOutboxRecord(eq("device-456"), anyString());
        verify(metricsService).incrementEventsProcessed();
    }

    @Test
    void processEvent_shouldIncrementMetricsAfterSuccessfulProcessing() {
        // When
        eventProcessorService.processEvent(testEvent);

        // Then
        verify(metricsService).incrementEventsProcessed();
    }

    @Test
    void processEvent_shouldThrowEventProcessingException_whenEventRepositoryFails() {
        // Given
        doThrow(new RuntimeException("Database error"))
                .when(eventRepository).save(any(DeviceEventEntity.class));

        // When & Then
        assertThatThrownBy(() -> eventProcessorService.processEvent(testEvent))
                .isInstanceOf(EventProcessingException.class)
                .hasMessageContaining("Failed to process event: event-123")
                .hasCauseInstanceOf(RuntimeException.class);

        verify(metricsService, never()).incrementEventsProcessed();
    }

    @Test
    void processEvent_shouldThrowEventProcessingException_whenOutboxRepositoryFails() {
        // Given
        doThrow(new RuntimeException("Outbox insert error"))
                .when(outboxRepository).createOutboxRecord(anyString(), anyString());

        // When & Then
        assertThatThrownBy(() -> eventProcessorService.processEvent(testEvent))
                .isInstanceOf(EventProcessingException.class)
                .hasMessageContaining("Failed to process event: event-123")
                .hasCauseInstanceOf(RuntimeException.class);

        verify(eventRepository).save(any(DeviceEventEntity.class));
        verify(metricsService, never()).incrementEventsProcessed();
    }

    @Test
    void processEvent_shouldCallRepositoriesInCorrectOrder() {
        // When
        eventProcessorService.processEvent(testEvent);

        // Then - verify order: first save event, then create outbox record
        var inOrder = inOrder(eventRepository, outboxRepository, metricsService);
        inOrder.verify(eventRepository).save(any(DeviceEventEntity.class));
        inOrder.verify(outboxRepository).createOutboxRecord(eq("device-456"), anyString());
        inOrder.verify(metricsService).incrementEventsProcessed();
    }

    @Test
    void processEvent_shouldHandleMultipleEvents() {
        // Given
        DeviceEvent event1 = DeviceEvent.newBuilder()
                .setEventId("event-1")
                .setDeviceId("device-1")
                .setTimestamp(System.currentTimeMillis())
                .setType("TEMPERATURE")
                .setPayload("{\"temp\": 20}")
                .build();

        DeviceEvent event2 = DeviceEvent.newBuilder()
                .setEventId("event-2")
                .setDeviceId("device-2")
                .setTimestamp(System.currentTimeMillis())
                .setType("HUMIDITY")
                .setPayload("{\"humidity\": 60}")
                .build();

        // When
        eventProcessorService.processEvent(event1);
        eventProcessorService.processEvent(event2);

        // Then
        verify(eventRepository, times(2)).save(any(DeviceEventEntity.class));
        verify(outboxRepository).createOutboxRecord(eq("device-1"), anyString());
        verify(outboxRepository).createOutboxRecord(eq("device-2"), anyString());
        verify(metricsService, times(2)).incrementEventsProcessed();
    }

    @Test
    void processEvent_shouldNotIncrementMetrics_whenExceptionOccurs() {
        // Given
        doThrow(new RuntimeException("Error"))
                .when(eventRepository).save(any(DeviceEventEntity.class));

        // When & Then
        assertThatThrownBy(() -> eventProcessorService.processEvent(testEvent))
                .isInstanceOf(EventProcessingException.class);

        verify(metricsService, never()).incrementEventsProcessed();
    }
}
