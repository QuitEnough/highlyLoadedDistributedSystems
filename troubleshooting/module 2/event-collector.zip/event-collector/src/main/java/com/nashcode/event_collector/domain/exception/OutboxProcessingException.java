package com.nashcode.event_collector.domain.exception;

public class OutboxProcessingException extends RuntimeException {
    public OutboxProcessingException(String message, Throwable cause) {
        super(message, cause);
    }
}
