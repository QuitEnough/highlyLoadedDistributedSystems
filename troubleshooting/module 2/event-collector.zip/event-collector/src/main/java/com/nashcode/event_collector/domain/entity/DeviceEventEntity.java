package com.nashcode.event_collector.domain.entity;

import com.nashcode.avro.DeviceEvent;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DeviceEventEntity {
    private String deviceId;
    private String eventId;
    private LocalDate eventDate;
    private long timestampMs;
    private String type;
    private String payload;

    public static DeviceEventEntity fromAvro(DeviceEvent avroEvent) {
        LocalDate eventDate = Instant.ofEpochMilli(avroEvent.getTimestamp())
                .atZone(ZoneOffset.UTC)
                .toLocalDate();

        return new DeviceEventEntity(
                avroEvent.getDeviceId(),
                avroEvent.getEventId(),
                eventDate,
                avroEvent.getTimestamp(),
                avroEvent.getType(),
                avroEvent.getPayload()
        );
    }
}
