package com.nashcode.event_collector.domain.entity;

import com.nashcode.event_collector.domain.model.OutboxStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeviceOutboxEntity {
    private String deviceId;
    private LocalDateTime createdAt;
    private OutboxStatus status;
    private LocalDateTime sentAt;
    private int attempts;
    private String lastError;
    private String traceparent;
}
