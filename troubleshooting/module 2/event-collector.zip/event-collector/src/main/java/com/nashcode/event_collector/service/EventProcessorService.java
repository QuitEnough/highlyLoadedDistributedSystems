package com.nashcode.event_collector.service;

import com.nashcode.avro.DeviceEvent;
import com.nashcode.event_collector.domain.entity.DeviceEventEntity;
import com.nashcode.event_collector.domain.exception.EventProcessingException;
import com.nashcode.event_collector.repository.DeviceEventRepository;
import com.nashcode.event_collector.repository.DeviceOutboxRepository;
import com.nashcode.event_collector.util.TraceContextUtil;
import io.micrometer.observation.annotation.Observed;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class EventProcessorService {
    private final DeviceEventRepository eventRepository;
    private final DeviceOutboxRepository outboxRepository;
    private final MetricsService metricsService;

    @Observed(name = "event.process")
    public void processEvent(DeviceEvent avroEvent) {
        String eventId = avroEvent.getEventId();
        String deviceId = avroEvent.getDeviceId();

        try {
            log.info("Processing event: eventId={}, deviceId={}", eventId, deviceId);

            DeviceEventEntity entity = DeviceEventEntity.fromAvro(avroEvent);

            eventRepository.save(entity);
            outboxRepository.createOutboxRecord(deviceId, TraceContextUtil.extractTraceparent());

            metricsService.incrementEventsProcessed();
        } catch (Exception e) {
            log.error("Failed to process event {}", eventId, e);
            throw new EventProcessingException("Failed to process event: " + eventId, e);
        }
    }
}
