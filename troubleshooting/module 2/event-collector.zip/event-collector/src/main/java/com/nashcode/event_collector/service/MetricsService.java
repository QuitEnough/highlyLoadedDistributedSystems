package com.nashcode.event_collector.service;

import com.nashcode.event_collector.repository.DeviceOutboxRepository;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.Getter;
import org.springframework.stereotype.Service;

@Service
@Getter
public class MetricsService {
    private final Counter eventsProcessedCounter;
    private final Counter outboxPublishSuccessCounter;
    private final Counter outboxPublishFailCounter;
    private final DeviceOutboxRepository outboxRepository;

    public MetricsService(MeterRegistry meterRegistry, DeviceOutboxRepository outboxRepository) {
        this.outboxRepository = outboxRepository;

        this.eventsProcessedCounter = Counter.builder("events.processed.total")
                .description("Total number of successfully processed events")
                .register(meterRegistry);

        this.outboxPublishSuccessCounter = Counter.builder("outbox.publish.success.total")
                .description("Total number of successfully published outbox records")
                .register(meterRegistry);

        this.outboxPublishFailCounter = Counter.builder("outbox.publish.fail.total")
                .description("Total number of failed outbox publish attempts")
                .register(meterRegistry);

        Gauge.builder("outbox.pending.count", this::getPendingCount)
                .description("Current number of pending outbox records (status=PENDING)")
                .register(meterRegistry);

        Gauge.builder("outbox.retrying.count", this::getRetryingCount)
                .description("Current number of retrying outbox records (status=RETRY)")
                .register(meterRegistry);
    }

    public void incrementEventsProcessed() {
        eventsProcessedCounter.increment();
    }

    public void incrementOutboxPublishSuccess() {
        outboxPublishSuccessCounter.increment();
    }

    public void incrementOutboxPublishFail() {
        outboxPublishFailCounter.increment();
    }

    private long getPendingCount() {
        try {
            return outboxRepository.countPending();
        } catch (Exception e) {
            return -1L;
        }
    }

    private long getRetryingCount() {
        try {
            return outboxRepository.countRetrying();
        } catch (Exception e) {
            return -1L;
        }
    }
}
