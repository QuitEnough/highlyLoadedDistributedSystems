package com.nashcode.event_collector.kafka.producer;

import com.nashcode.avro.Device;
import com.nashcode.avro.DeviceEvent;
import com.nashcode.event_collector.domain.exception.OutboxProcessingException;
import io.opentelemetry.instrumentation.annotations.WithSpan;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.time.Instant;

@Slf4j
@Component
@RequiredArgsConstructor
public class DevicePublisher {
    private final KafkaTemplate<String, Device> kafkaTemplate;

    @Value("${kafka.topics.devices}")
    private String devicesTopic;

    @WithSpan("devices publish")
    public void publishDevice(DeviceEvent deviceEvent) {
        String eventId = deviceEvent.getEventId();
        String deviceId = deviceEvent.getDeviceId();

        try {
            Device device = Device.newBuilder()
                    .setDeviceId(deviceEvent.getDeviceId())
                    .setDeviceType(deviceEvent.getType())
                    .setCreatedAt(Instant.now().toEpochMilli())
                    .setMeta("")
                    .build();

            ProducerRecord<String, Device> record = new ProducerRecord<>(devicesTopic, deviceId, device);

            kafkaTemplate.send(record).join();

            log.info("Published device event {} for device {} to Kafka topic '{}' with trace context",
                    eventId, deviceId, devicesTopic);

        } catch (Exception e) {
            log.error("Failed to publish device event {} to Kafka", eventId, e);
            throw new OutboxProcessingException("Failed to publish device event to Kafka: " + eventId, e);
        }
    }
}
