package com.nashcode.event_collector.repository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
@RequiredArgsConstructor
public class RedisDeduplicationRepository {
    private static final String DEVICES_PUBLISHED_KEY = "devices:published";

    private final RedisTemplate<String, String> redisTemplate;

    public boolean addToPublishedIfNew(String deviceId) {
        Long added = redisTemplate.opsForSet().add(DEVICES_PUBLISHED_KEY, deviceId);
        boolean isNew = added != null && added > 0;
        if (isNew) {
            log.info("Device {} is new for publishing, added to devices:published", deviceId);
        } else {
            log.info("Device {} already exists in devices:published", deviceId);
        }
        return isNew;
    }
}
