package com.nashcode.event_collector.domain.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum OutboxStatus {
    PENDING(0),
    RETRY(1),
    SENT(2),
    FAILED(3);

    private final int value;

    public static OutboxStatus fromValue(int value) {
        for (OutboxStatus status : OutboxStatus.values()) {
            if (status.value == value) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unknown OutboxStatus value: " + value);
    }
}
