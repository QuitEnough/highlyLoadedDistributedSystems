package com.nashcode.event_collector.kafka.consumer;

import com.nashcode.avro.DeviceEvent;
import com.nashcode.event_collector.service.EventProcessorService;
import io.micrometer.observation.annotation.Observed;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class DeviceEventListener {
    private final EventProcessorService eventProcessorService;

    @Observed(name = "kafka.consume.device-event")
    @KafkaListener(
            topics = "${kafka.topics.events}",
            containerFactory = "kafkaListenerContainerFactory"
    )
    public void listen(ConsumerRecord<String, DeviceEvent> record, Acknowledgment acknowledgment) {
        try {
            DeviceEvent event = record.value();
            log.info("Received Kafka message: topic={}, partition={}, offset={}, eventId={}",
                    record.topic(), record.partition(), record.offset(), event.getEventId());

            eventProcessorService.processEvent(event);

            acknowledgment.acknowledge();
            log.info("Acknowledged Kafka offset: {}", record.offset());

        } catch (Exception e) {
            log.error("Processing failed for event, will retry on next poll", e);
        }
    }
}
