package com.nashcode.event_collector.scheduler;

import com.nashcode.event_collector.service.OutboxProcessorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class OutboxScheduler {
    private final OutboxProcessorService outboxProcessorService;

    @Scheduled(cron = "${outbox.processor.cron}")
    public void processOutbox() {
        log.info("Running outbox processor scheduled task");
        try {
            outboxProcessorService.processOutboxRecords();
        } catch (Exception e) {
            log.error("Outbox processor scheduled task failed", e);
            // Don't rethrow - let scheduler re-process the row
        }
    }
}
