package com.nashcode.event_collector.service;

import com.nashcode.avro.DeviceEvent;
import com.nashcode.event_collector.domain.entity.DeviceOutboxEntity;
import com.nashcode.event_collector.domain.exception.OutboxProcessingException;
import com.nashcode.event_collector.kafka.producer.DevicePublisher;
import com.nashcode.event_collector.repository.DeviceEventRepository;
import com.nashcode.event_collector.repository.DeviceOutboxRepository;
import com.nashcode.event_collector.repository.RedisDeduplicationRepository;
import com.nashcode.event_collector.util.TraceContextUtil;
import io.micrometer.observation.annotation.Observed;
import io.opentelemetry.api.trace.*;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class OutboxProcessorService {
    private static final String LOCK_PREFIX = "outbox:lock:";

    private final DeviceOutboxRepository outboxRepository;
    private final DeviceEventRepository eventRepository;
    private final DistributedLockService lockService;
    private final DevicePublisher devicePublisher;
    private final RedisDeduplicationRepository deduplicationRepository;
    private final MetricsService metricsService;
    private final Tracer tracer;
    private final int maxAttempts;

    public OutboxProcessorService(
            DeviceOutboxRepository outboxRepository,
            DeviceEventRepository eventRepository,
            DistributedLockService lockService,
            DevicePublisher devicePublisher,
            RedisDeduplicationRepository deduplicationRepository,
            MetricsService metricsService,
            Tracer tracer,
            @Value("${outbox.processor.max-attempts}") int maxAttempts
    ) {
        this.outboxRepository = outboxRepository;
        this.eventRepository = eventRepository;
        this.lockService = lockService;
        this.devicePublisher = devicePublisher;
        this.deduplicationRepository = deduplicationRepository;
        this.metricsService = metricsService;
        this.tracer = tracer;
        this.maxAttempts = maxAttempts;
    }

    @Observed(name = "outbox.process-next")
    public void processOutboxRecords() {
        List<DeviceOutboxEntity> outboxRecords = outboxRepository.findOldestDevicesToProcess();
        if (outboxRecords.isEmpty()) {
            log.info("No pending outboxRecords records found");
            return;
        }

        for (DeviceOutboxEntity outboxRecord : outboxRecords) {
            processOutboxRecordWithSpan(outboxRecord);
        }
    }

    private void processOutboxRecordWithSpan(DeviceOutboxEntity outboxRecord) {
        String deviceId = outboxRecord.getDeviceId();
        String traceparent = outboxRecord.getTraceparent();

        SpanContext parentSpanContext = TraceContextUtil.createSpanContext(traceparent);

        Context remoteParentContext = Context.root().with(Span.wrap(parentSpanContext));

        SpanBuilder spanBuilder = tracer.spanBuilder("outbox.process")
                .setParent(remoteParentContext)
                .setSpanKind(SpanKind.INTERNAL)
                .setAttribute("device.id", deviceId)
                .setAttribute("traceparent.restored", traceparent != null && !traceparent.isEmpty());

        Span span = spanBuilder.startSpan();

        try (Scope spanScope = span.makeCurrent()) {
            processOutboxRecord(outboxRecord);
        } catch (Exception e) {
            span.recordException(e);
            throw e;
        } finally {
            span.end();
        }
    }

    private void processOutboxRecord(DeviceOutboxEntity outboxRecord) {
        String deviceId = outboxRecord.getDeviceId();
        String lockKey = LOCK_PREFIX + deviceId;

        int attempts = outboxRecord.getAttempts();

        if (attempts >= maxAttempts) {
            log.warn("Outbox record {} exceeded max attempts ({}), marking as FAILED", deviceId, maxAttempts);
            outboxRepository.updateToFailed(deviceId, "Exceeded max attempts: " + maxAttempts);
            return;
        }

        if (!lockService.acquireLock(lockKey)) {
            log.info("Could not acquire lock for device {}, another instance processing", deviceId);
            return;
        }

        try {
            boolean isNewDevice = deduplicationRepository.addToPublishedIfNew(deviceId);

            if (!isNewDevice) {
                log.info("Device {} already published (detected via Redis SADD), marking outboxRecords as SENT", deviceId);
                outboxRepository.updateToSent(deviceId);
                metricsService.incrementOutboxPublishSuccess();
                return;
            }

            DeviceEvent deviceEvent = eventRepository.findFirstEventByDeviceId(deviceId);
            devicePublisher.publishDevice(deviceEvent);
            outboxRepository.updateToSent(deviceId);

            metricsService.incrementOutboxPublishSuccess();
            log.info("Published device {} to Kafka topic 'devices'", deviceId);

        } catch (Exception e) {
            log.error("Failed to process outboxRecords record for device {}", deviceId, e);
            outboxRepository.updateToRetry(deviceId, e.getMessage());
            metricsService.incrementOutboxPublishFail();
            throw new OutboxProcessingException("Failed to process outboxRecords for device: " + deviceId, e);
        } finally {
            lockService.releaseLock(lockKey);
        }
    }
}
