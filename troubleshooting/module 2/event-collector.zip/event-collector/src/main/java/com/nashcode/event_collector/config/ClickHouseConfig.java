package com.nashcode.event_collector.config;

import com.clickhouse.jdbc.ClickHouseDataSource;
import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.instrumentation.jdbc.datasource.OpenTelemetryDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.Properties;

@Configuration
public class ClickHouseConfig {

    @Value("${spring.datasource.url}")
    private String url;

    @Value("${spring.datasource.username}")
    private String username;

    @Value("${spring.datasource.password}")
    private String password;

    @Value("${clickhouse.socket-timeout}")
    private String socketTimeout;

    @Value("${clickhouse.connection-timeout}")
    private String connectionTimeout;

    @Value("${clickhouse.data-transfer-timeout}")
    private String dataTransferTimeout;

    @Value("${clickhouse.keep-alive-timeout}")
    private String keepAliveTimeout;

    @Value("${clickhouse.auto-reconnect}")
    private String autoReconnect;

    @Value("${clickhouse.failover-retries}")
    private String failoverRetries;

    @Bean
    public DataSource clickHouseDataSource() throws SQLException {
        Properties properties = new Properties();
        properties.setProperty("user", username);
        properties.setProperty("password", password);

        properties.setProperty("socket_timeout", socketTimeout);
        properties.setProperty("connection_timeout", connectionTimeout);
        properties.setProperty("dataTransferTimeout", dataTransferTimeout);
        properties.setProperty("keepAliveTimeout", keepAliveTimeout);

        properties.setProperty("auto_reconnect", autoReconnect);
        properties.setProperty("failover", failoverRetries);

        ClickHouseDataSource clickHouseDataSource = new ClickHouseDataSource(url, properties);
        return new OpenTelemetryDataSource(clickHouseDataSource, GlobalOpenTelemetry.get());
    }

    @Bean
    public JdbcTemplate clickHouseJdbcTemplate() throws SQLException {
        return new JdbcTemplate(clickHouseDataSource());
    }
}
