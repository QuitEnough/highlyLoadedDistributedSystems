package com.nashcode.event_collector.util;

import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanContext;
import io.opentelemetry.api.trace.TraceFlags;
import io.opentelemetry.api.trace.TraceState;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class TraceContextUtil {

    /**
     * Extracts current trace context in W3C traceparent format.
     * Format: 00-{trace_id}-{span_id}-{trace_flags}
     */
    public static String extractTraceparent() {
        Span currentSpan = Span.current();
        SpanContext spanContext = currentSpan.getSpanContext();

        if (!spanContext.isValid()) {
            log.info("No valid span context available, returning empty traceparent");
            return "";
        }

        String traceId = spanContext.getTraceId();
        String spanId = spanContext.getSpanId();
        String traceFlags = String.format("%02x", spanContext.getTraceFlags().asByte());

        String traceparent = String.format("00-%s-%s-%s", traceId, spanId, traceFlags);
        log.info("Extracted traceparent: {}", traceparent);

        return traceparent;
    }

    /**
     * Parses W3C traceparent header.
     * Format: 00-{trace_id}-{span_id}-{trace_flags}
     */
    public static TraceContext parseTraceparent(String traceparent) {
        if (traceparent == null || traceparent.isEmpty()) {
            log.info("Empty traceparent provided");
            return null;
        }

        String[] parts = traceparent.split("-");
        if (parts.length != 4) {
            log.warn("Invalid traceparent format: {}", traceparent);
            return null;
        }

        String version = parts[0];
        if (!"00".equals(version)) {
            log.warn("Unsupported traceparent version: {}", version);
            return null;
        }

        String traceId = parts[1];
        String spanId = parts[2];
        String traceFlags = parts[3];

        log.info("Parsed traceparent - traceId: {}, spanId: {}, traceFlags: {}", traceId, spanId, traceFlags);

        return new TraceContext(traceId, spanId, traceFlags);
    }

    /**
     * Creates a SpanContext from W3C traceparent header.
     * This can be used to restore the parent span context for distributed tracing.
     */
    public static SpanContext createSpanContext(String traceparent) {
        TraceContext traceContext = parseTraceparent(traceparent);
        if (traceContext == null) {
            log.info("Cannot create SpanContext from invalid traceparent");
            return SpanContext.getInvalid();
        }

        try {
            // Parse trace flags from hex string (e.g., "01" -> 0x01)
            byte traceFlagsByte = (byte) Integer.parseInt(traceContext.getTraceFlags(), 16);
            TraceFlags traceFlags = TraceFlags.fromByte(traceFlagsByte);

            SpanContext spanContext = SpanContext.createFromRemoteParent(
                    traceContext.getTraceId(),
                    traceContext.getSpanId(),
                    traceFlags,
                    TraceState.getDefault()
            );

            log.info("Created SpanContext from traceparent - traceId: {}, spanId: {}",
                    traceContext.getTraceId(), traceContext.getSpanId());

            return spanContext;
        } catch (Exception e) {
            log.warn("Failed to create SpanContext from traceparent: {}", traceparent, e);
            return SpanContext.getInvalid();
        }
    }

    public static class TraceContext {
        private final String traceId;
        private final String spanId;
        private final String traceFlags;

        public TraceContext(String traceId, String spanId, String traceFlags) {
            this.traceId = traceId;
            this.spanId = spanId;
            this.traceFlags = traceFlags;
        }

        public String getTraceId() {
            return traceId;
        }

        public String getSpanId() {
            return spanId;
        }

        public String getTraceFlags() {
            return traceFlags;
        }
    }
}
