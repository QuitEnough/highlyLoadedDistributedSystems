package com.nashcode.event_collector.repository;

import com.nashcode.event_collector.domain.entity.DeviceOutboxEntity;
import com.nashcode.event_collector.domain.model.OutboxStatus;
import io.micrometer.observation.annotation.Observed;
import io.opentelemetry.instrumentation.annotations.WithSpan;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

@Slf4j
@Repository
public class DeviceOutboxRepository {
    private final JdbcTemplate jdbcTemplate;
    private final String database;

    public DeviceOutboxRepository(
            JdbcTemplate clickHouseJdbcTemplate,
            @Value("${clickhouse.database}") String database) {
        this.jdbcTemplate = clickHouseJdbcTemplate;
        this.database = database;
    }

    @WithSpan("device-outbox-repository#create-outbox-record")
    @Observed(name = "outbox.create")
    public void createOutboxRecord(String deviceId, String traceparent) {
        String sql = String.format("""
                INSERT INTO %s.device_outbox
                (device_id, created_at, status, attempts, traceparent)
                VALUES (?, now(), ?, 0, ?)
                """, database);

        jdbcTemplate.update(sql, deviceId, OutboxStatus.PENDING.getValue(), traceparent);
        log.info("Created outbox record: deviceId={}, traceparent={}", deviceId, traceparent);
    }

    @WithSpan("device-outbox-repository#find-oldest-devices-to-process")
    @Observed(name = "outbox.find-oldest")
    public List<DeviceOutboxEntity> findOldestDevicesToProcess() {
        String sql = String.format("""
                SELECT device_id, created_at, status, sent_at, attempts, last_error, traceparent
                FROM %s.device_outbox
                WHERE status IN (?, ?)
                ORDER BY created_at ASC
                LIMIT 100
                """, database);

        return jdbcTemplate.query(sql, new OutboxRowMapper(),
                OutboxStatus.PENDING.getValue(), OutboxStatus.RETRY.getValue());
    }

    public long countPending() {
        String sql = String.format("""
                SELECT count()
                FROM %s.device_outbox
                WHERE status = ?
                """, database);

        Long count = jdbcTemplate.queryForObject(sql, Long.class, OutboxStatus.PENDING.getValue());
        return count != null ? count : 0L;
    }

    public long countRetrying() {
        String sql = String.format("""
                SELECT count()
                FROM %s.device_outbox
                WHERE status = ?
                """, database);

        Long count = jdbcTemplate.queryForObject(sql, Long.class, OutboxStatus.RETRY.getValue());
        return count != null ? count : 0L;
    }

    @WithSpan("device-outbox-repository#update-to-sent")
    @Observed(name = "outbox.update-sent")
    public void updateToSent(String deviceId) {
        String sql = String.format("""
                ALTER TABLE %s.device_outbox
                UPDATE status = ?, sent_at = now()
                WHERE device_id = ?
                """, database);

        jdbcTemplate.update(sql, OutboxStatus.SENT.getValue(), deviceId);
        log.info("Updated outbox record to SENT: deviceId={}", deviceId);
    }

    @WithSpan("device-outbox-repository#update-to-retry")
    public void updateToRetry(String deviceId, String error) {
        String sql = String.format("""
                ALTER TABLE %s.device_outbox
                UPDATE status = ?, attempts = attempts + 1, last_error = ?
                WHERE device_id = ?
                """, database);

        jdbcTemplate.update(sql, OutboxStatus.RETRY.getValue(), error, deviceId);
        log.info("Updated outbox record to RETRY: deviceId={}, error={}", deviceId, error);
    }

    @WithSpan("device-outbox-repository#update-to-failed")
    public void updateToFailed(String deviceId, String error) {
        String sql = String.format("""
                ALTER TABLE %s.device_outbox
                UPDATE status = ?, last_error = ?
                WHERE device_id = ?
                """, database);

        jdbcTemplate.update(sql, OutboxStatus.FAILED.getValue(), error, deviceId);
        log.warn("Updated outbox record to FAILED: deviceId={}, error={}", deviceId, error);
    }

    private static class OutboxRowMapper implements RowMapper<DeviceOutboxEntity> {
        @Override
        public DeviceOutboxEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
            DeviceOutboxEntity entity = new DeviceOutboxEntity();
            entity.setDeviceId(rs.getString("device_id"));

            Timestamp createdAtTimestamp = rs.getTimestamp("created_at");
            entity.setCreatedAt(createdAtTimestamp != null ? createdAtTimestamp.toLocalDateTime() : null);

            entity.setStatus(OutboxStatus.fromValue(rs.getInt("status")));

            Timestamp sentAtTimestamp = rs.getTimestamp("sent_at");
            entity.setSentAt(sentAtTimestamp != null ? sentAtTimestamp.toLocalDateTime() : null);

            entity.setAttempts(rs.getInt("attempts"));
            entity.setLastError(rs.getString("last_error"));
            entity.setTraceparent(rs.getString("traceparent"));
            return entity;
        }
    }
}
