package com.nashcode.event_collector.repository;

import com.nashcode.avro.DeviceEvent;
import com.nashcode.event_collector.domain.entity.DeviceEventEntity;
import io.micrometer.observation.annotation.Observed;
import io.opentelemetry.instrumentation.annotations.WithSpan;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
public class DeviceEventRepository {
    private final JdbcTemplate jdbcTemplate;
    private final String database;

    public DeviceEventRepository(
            JdbcTemplate clickHouseJdbcTemplate,
            @Value("${clickhouse.database}") String database
    ) {
        this.jdbcTemplate = clickHouseJdbcTemplate;
        this.database = database;
    }

    @WithSpan("device-event-repository#save")
    @Observed(name = "event.save")
    public void save(DeviceEventEntity event) {
        String sql = String.format("""
                INSERT INTO %s.device_events
                (device_id, event_id, event_date, timestamp_ms, type, payload)
                VALUES (?, ?, ?, ?, ?, ?)
                """, database);

        jdbcTemplate.update(sql,
                event.getDeviceId(),
                event.getEventId(),
                event.getEventDate(),
                event.getTimestampMs(),
                event.getType(),
                event.getPayload()
        );

        log.info("Saved event to {}.device_events: eventId={}, deviceId={}", database, event.getEventId(), event.getDeviceId());
    }

    @WithSpan("device-event-repository#find-first-by-device-id")
    public DeviceEvent findFirstEventByDeviceId(String deviceId) {
        String sql = String.format("""
                SELECT device_id, event_id, timestamp_ms, type, payload
                FROM %s.device_events
                WHERE device_id = ?
                ORDER BY timestamp_ms ASC
                LIMIT 1
                """, database);

        return jdbcTemplate.queryForObject(sql, (rs, rowNum) ->
                DeviceEvent.newBuilder()
                        .setDeviceId(rs.getString("device_id"))
                        .setEventId(rs.getString("event_id"))
                        .setTimestamp(rs.getLong("timestamp_ms"))
                        .setType(rs.getString("type"))
                        .setPayload(rs.getString("payload"))
                        .build(),
                deviceId
        );
    }
}
