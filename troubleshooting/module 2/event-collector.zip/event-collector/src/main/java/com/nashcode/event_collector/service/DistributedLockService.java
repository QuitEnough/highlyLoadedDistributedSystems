package com.nashcode.event_collector.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;

@Slf4j
@Service
public class DistributedLockService {
    private static final String LOCK_VALUE = "locked";

    private final RedisTemplate<String, String> redisTemplate;
    private final long lockTtlSeconds;

    public DistributedLockService(
            RedisTemplate<String, String> redisTemplate,
            @Value("${outbox.processor.lock-ttl-seconds}") long lockTtlSeconds) {
        this.redisTemplate = redisTemplate;
        this.lockTtlSeconds = lockTtlSeconds;
    }

    public boolean acquireLock(String lockKey) {
        Boolean acquired = redisTemplate
                .opsForValue()
                .setIfAbsent(lockKey, LOCK_VALUE, Duration.ofSeconds(lockTtlSeconds));

        boolean success = acquired != null && acquired;
        if (success) {
            log.info("Acquired lock: {}", lockKey);
        } else {
            log.info("Failed to acquire lock: {}", lockKey);
        }
        return success;
    }

    public void releaseLock(String lockKey) {
        redisTemplate.delete(lockKey);
        log.info("Released lock: {}", lockKey);
    }
}
