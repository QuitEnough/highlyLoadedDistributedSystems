-- Migration: Add traceparent column to device_outbox table
-- Purpose: Store W3C Trace Context for distributed tracing across async boundaries
-- Date: 2026-02-04

-- Add traceparent column (W3C format: 00-<trace_id>-<span_id>-<trace_flags>)
ALTER TABLE telemetry.device_outbox
ADD COLUMN IF NOT EXISTS traceparent String DEFAULT '';

-- Example value: 00-0af7651916cd43dd8448eb211c80319c-b7ad6b7169203331-01
