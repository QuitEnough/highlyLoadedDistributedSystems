-- ClickHouse Schema Initialization for Event Collector Service
-- Flyway Migration V1: Initial schema

-- Create device_events table
CREATE TABLE IF NOT EXISTS telemetry.device_events (
    device_id String,
    event_id String,
    event_date Date,
    timestamp_ms Int64,
    type String,
    payload String
)
ENGINE = MergeTree()
PARTITION BY event_date
ORDER BY (device_id, event_date, timestamp_ms, event_id);

-- Create device_outbox table
CREATE TABLE IF NOT EXISTS telemetry.device_outbox (
    device_id String,
    created_at DateTime,
    status UInt8, -- 0 = PENDING, 1 = RETRY, 2 = SENT, 3 = FAILED
    sent_at Nullable(DateTime),
    attempts UInt32 DEFAULT 0,
    last_error Nullable(String)
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(created_at)
ORDER BY (created_at, device_id);
