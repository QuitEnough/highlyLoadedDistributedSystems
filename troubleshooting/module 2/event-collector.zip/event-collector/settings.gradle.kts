rootProject.name = "event-collector"
