plugins {
	java
	alias(libs.plugins.springBoot)
	alias(libs.plugins.springDependencyManagement)
	alias(libs.plugins.avro)
}

group = "com.nashcode"
version = "0.0.1-SNAPSHOT"
description = "Event Collector Service"

java {
	toolchain {
		languageVersion = JavaLanguageVersion.of(24)
	}
}

repositories {
	mavenCentral()
	maven("https://packages.confluent.io/maven/")
}

dependencies {
	// Lombok
	compileOnly(libs.lombok)
	annotationProcessor(libs.lombok)
	testCompileOnly(libs.lombok)
	testAnnotationProcessor(libs.lombok)

	// Spring
	implementation(libs.bundles.spring.core)
	implementation(libs.bundles.spring.kafka)
	testImplementation(libs.bundles.spring.test)

	// Observability
	runtimeOnly(libs.micrometer.registry.prometheus)
	implementation(libs.bundles.observability.micrometer)
	implementation(libs.bundles.observability.opentelemetry)
	implementation(platform(libs.opentelemetry.instrumentation.bom.alpha))

	// JUnit
	testRuntimeOnly(libs.junit.platform.launcher)
	testImplementation(libs.awaitility)

	// Kafka Avro + Schema Registry
	implementation(libs.bundles.kafka.avro)

	// ClickHouse
	implementation(libs.clickhouse.jdbc)

	// Flyway (database migrations)
	implementation(libs.flyway.core)
	implementation(libs.flyway.database.clickhouse)

	// Apache HttpClient 5 (required by ClickHouse JDBC and Spring Boot HTTP client)
	implementation(libs.bundles.apache.http)

	// Testcontainers
	testImplementation(libs.bundles.testcontainers)
}

tasks.withType<Test> {
	useJUnitPlatform()
}

avro {
	outputCharacterEncoding.set("UTF-8")
	stringType.set("String")
}
